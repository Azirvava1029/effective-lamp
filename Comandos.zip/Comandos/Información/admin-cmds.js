module.exports = ({
name: "admin-cmds",
code: `
$footer[Desarrollado por HuguitisYT#1234]
$color[GREEN]

$description[
**- Bot creado por HuguitisYT#1234
- Código: https://github.com/Huguitis/account-manager
- Soporte: http://discord.link/huguitis
- Comandos normales: +comandos**

\`+eval\` - Ejecuta un código desde Discord.
\`+bot-blacklist\` - Bloquea a alguien el uso del bot.
\`+bot-unblacklist\` - Desbloquea a alguien el uso del bot.
\`+add-lanos\` - Añade lanos a algún usuario.
\`+remove-lanos\` - Retira lanos a algún usuario.
]
` 
})