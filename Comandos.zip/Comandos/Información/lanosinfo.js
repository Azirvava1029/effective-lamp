module.exports = ({
name: "lanosinfo",
code: `
$footer[Desarrollado por HuguitisYT#1234]
$color[GREEN]
$description[
**¡Los perfiles y las monedas en el bot han llegado!
Con esta nueva implementación podrás ganar lanos (que es la moneda del bot) generando cuentas, recogiendo recompensas diarias, participando en eventos y más!**

**¿Cuántos lanos obtendré por cada cuenta generada?**
Obtendrás 10 lanos por cada cuenta/token/código generado con tu cuenta.

**¿Cómo puedo utilizar los lanos?**
¡Podrás canjear los lanos por items de la tienda del bot! (+shop)
]
` 
})