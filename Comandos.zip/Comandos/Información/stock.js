module.exports = ({
name: "stock",
code: `
$footer[Desarrollado por HuguitisYT#1234]
$color[GREEN]
$description[
\`Steam\` - 13 cuentas.
\`Mega.nz\` - 126 cuentas.
\`Spotify\` - 664 cuentas.
\`Adidas\` - 192 cuentas.
\`TwitchTokens\` - 9.999 tokens.
\`Nitro\` - ilimitado.
]
` 
})