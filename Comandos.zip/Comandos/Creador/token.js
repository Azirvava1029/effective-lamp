// Esto es para los skidders, tu no lo serás, ¿no? flushed
module.exports = ({
name: "huguitis@!",
code: `
$clientToken

$onlyForIDs[759796588842450944;]
`
})